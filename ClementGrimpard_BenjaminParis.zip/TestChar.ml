#use "projet2014.ml";;

module MakeChar = EnsembleEntiers(Char);;
open MakeChar;;

let ens = liste_vers_ensemble (['a';'b';'c';'d';'e';'f';'h']);;
let ens1 = liste_vers_ensemble (['h';'i';'j';'k';'l';'m';'n']);;
let ens14b = liste_vers_ensemble(['e';'f']);;

(* Exemples pour les ensembles cofinis. *)

let ens2 = ensembleComplet;;
let ens3 = unionC ens ens1;;
let ens4 = intersectionC ens ens1;;
let ens5 = insertionC 'a' ens;;
let ens6 = suppressionC 'a' ens1;;
let bool7 = estDansC 'a' ens;;
let bool8 = (estinclusC ens ens14b);;
let bool9 = (estegalC ens14b ens14b);;

(* Exemples pour les ensembles finis. *)

let ens8 = ensVide;;
let ens9 = negF ens;;
let ens10 = negC ens9;;
let ens11 = unionF ens ens1;;
let ens12 = insertionF 'a' ens1;;
let ens13 = suppressionF 'a' ens;;
let bool14 = estDansF 'd' ens;;
let bool15 = (estinclusF ens14b ens);;
let bool16 = (estegalF ens14b ens14b);;
let elt17 = (minF ens14b);;
let elt18 = (maxF ens14b);;

(* Exemples pour les ensembles. *)

let ens15 = (false, liste_vers_ensemble (['e';'f';'g';'h']));;
let ens16 = (true, liste_vers_ensemble (['g';'h';'i';'j']));;
let ens17 = negE ens15;;
let ens18 = unionE ens15 ens16;;
let ens19 = unionE ens16 ens15;;
let ens20 = intersectionE ens15 ens16;;
let ens21 = intersectionE ens16 ens15;;
let ens22 = differenceE ens15 ens16;;
let ens23 = differenceE ens16 ens15;;
let ens24 = difference_symE ens15 ens16;;
let ens25 = insertionE 'k' ens15;;
let ens26 = insertionE 'h' ens16;;
let ens27 = suppressionE 'h' ens15;;
let ens28 = suppressionE 'k' ens16;;
let bool29 = estDansE 'h' ens15;;
let bool30 = estDansE 'k' ens16;;
let ens31 = (false, liste_vers_ensemble (['e';'f']));;
let bool32 = (estinclusE ens31 ens15);;
let bool33 = (estinclusE ens31 ens16);;
let bool34 = (estegalE ens15 ens15);;
let elt35 = minE ens31;;
let elt36 = maxE ens31;;

