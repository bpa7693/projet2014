module type Type_Ordonne = 
sig
  type t
  val compare : t -> t -> int
end;;

module Entier = 
struct
  type t = int;;
  let compare (a : t) (b : t) =
    if (a > b) then
      1 
    else if (a = b) then 
      0 
    else -1
  ;;
end;;

module Char = 
struct
  type t = char;;
  let compare (a : t) (b : t) =
    if (a > b) then
      1 
    else if (a = b) then 
      0 
    else -1
  ;;
end;;

module CoupleInt = 
struct
  type t = int * int;;
  let compare (a : t) (b : t) =
    if (a > b) then
      1 
    else if (a = b) then 
      0 
    else -1
  ;;
end;;

module String = 
struct
  type t = string;;
  let compare (a : t) (b : t) =
    if (a > b) then
      1 
    else if (a = b) then 
      0 
    else -1
  ;;
end;;

module type IEnsembleEntiers = functor (Ord : Type_Ordonne) ->
sig

  type element = Ord.t;;
  type couleur = Noir | Rouge;;
  type abc =
    Vide
  | Noeud of couleur * element * abc * abc;;
  
  val recherche_abc : abc -> element -> bool
  val rotation_d : abc -> abc
  val rotation_g : abc -> abc
  val equilibre : abc -> abc
  val inser_rech : element -> abc -> abc  
  val inser_bicolore : element -> abc -> abc
  val suppression_equilibreg : abc -> bool * abc
  val suppression_equilibred : abc -> bool * abc
  val succ_arbre : abc -> bool * element * abc
  val suppression_rech : element -> abc -> bool * abc
  val suppression : element -> abc -> abc 
  val est_vide : abc -> bool
  val appartient_a : abc -> element -> bool 
  val inserer : element -> abc -> abc 
  val supprimer : element -> abc -> abc
  val min : abc -> element 
  val max : abc -> element
  val decouper_selon_min : abc -> element * abc 
  val decouper_selon_max : abc -> element * abc 
  val union : abc -> abc -> abc
  val intersection : abc -> abc -> abc
  val ensemble_vers_liste : abc -> element list
  val liste_vers_ensemble : element list -> abc
  val inclus : abc -> abc -> bool
  val egal : abc -> abc -> bool
					       
  type ensCo = abc;;
  
  val ensembleComplet : ensCo
  val unionC : ensCo -> ensCo -> ensCo
  val intersectionC : ensCo -> ensCo -> ensCo
  val insertionC : element -> ensCo -> ensCo
  val suppressionC : element -> ensCo -> ensCo
  val estDansC : element -> ensCo -> bool
  val estinclusC : ensCo -> ensCo -> bool
  val estegalC : ensCo -> ensCo -> bool

  type ensFin = abc;;

  val ensVide : ensFin 
  val negF : ensFin -> ensCo
  val negC : ensCo -> ensFin 
  val unionF : ensFin -> ensFin -> ensFin 
  val intersectionF : ensFin -> ensFin -> ensFin 
  val insertionF : element -> ensFin -> ensFin
  val suppressionF : element -> ensFin -> ensFin 
  val estDansF : element -> ensFin -> bool
  val estinclusF : ensFin -> ensFin -> bool
  val estegalF : ensFin -> ensFin -> bool
  val minF : ensFin -> element
  val maxF : ensFin -> element

  type flag = bool;; 
  type ensemble = abc;;
  type ens = flag * ensemble;;

  val negE : ens -> ens
  val unionE : ens -> ens -> ens
  val intersectionE : ens -> ens -> ens
  val differenceE : ens -> ens -> ens  
  val difference_symE : ens -> ens -> ens 
  val insertionE : element -> ens -> ens
  val suppressionE : element -> ens -> ens
  val estDansE : element -> ens -> bool
  val estinclusE : ens -> ens -> bool
  val estegalE : ens -> ens -> bool
  val minE : ens -> element
  val maxE : ens -> element
end;;

module EnsembleEntiers : IEnsembleEntiers = functor (Ord : Type_Ordonne) ->
struct 
  
  type element = Ord.t;;
  type couleur = Noir | Rouge;;
  type abc =
    Vide
  | Noeud of couleur * element * abc * abc;;

  let rec recherche_abc a (e : element) = match a with
      Vide -> false
    | Noeud(c, n, sg, sd) when ((Ord.compare e n) = 0) -> true
    | Noeud(c, n, sg, sd) when ((Ord.compare e n) = 1) -> (recherche_abc sd e)
    | Noeud(c, n, sg, sd) -> (recherche_abc sg e)
  ;;

  let rotation_d = function
  Noeud(c, x, Noeud(cc, y, sag, sad), sadd)
  -> Noeud(cc, y, sag, Noeud(c, x, sad, sadd))
    |_ -> failwith "erreur"
  ;;


  let rotation_g = function
  Noeud(c, x, sag, Noeud(cc, y, sagg, sadd))
  -> Noeud(cc, y, Noeud(c, x, sag, sagg), sadd)
    |_-> failwith "erreur"
  ;;

  let equilibre arb = match arb with
    (*cas sans rotations*)
      Noeud(Noir, g, Noeud(Rouge, p, Noeud(Rouge, x, sag, sad), sadd), Noeud(Rouge, f, saggg, saddd)) ->
	Noeud(Rouge, g, Noeud(Noir, p, Noeud(Rouge, x, sag, sad), sadd), Noeud(Noir, f, saggg, saddd))
    |Noeud(Noir, g, Noeud(Rouge, p, sagg, Noeud(Rouge, x, sag, sad)), Noeud(Rouge, f, saggg, saddd)) ->
      Noeud(Rouge, g, Noeud(Noir, p, sagg, Noeud(Rouge, x, sag, sad)), Noeud(Noir, f, saggg, saddd))
    |Noeud(Noir, g, Noeud(Rouge, f, sag, sad), Noeud(Rouge, p, sagg, Noeud(Rouge, x, saggg, saddd))) -> 
      Noeud(Rouge, g, Noeud(Noir, f, sag, sad), Noeud(Noir, p, sagg, Noeud(Rouge, x, saggg, saddd)))
    |Noeud(Noir, g, Noeud(Rouge, f, sag, sad), Noeud(Rouge, p, Noeud(Rouge, x, saggg, saddd), sadd)) ->
      Noeud(Rouge, g, Noeud(Noir, f, sag, sad), Noeud(Noir, p, Noeud(Rouge, x, saggg, saddd), sadd))
  (*cas avec rotations*)
  (*cas 1 :*)
    |Noeud(Noir, g, Noeud(Rouge, p, Noeud(Rouge, x, sag, sad), sadd), Noeud(Noir, f, saggg, saddd)) ->
      Noeud(Noir, p, Noeud(Rouge, x, sag, sad), Noeud(Rouge, g, sadd, Noeud(Noir, f, saggg, saddd)))
    |Noeud(Noir, g, Noeud(Rouge, p, Noeud(Rouge, x, sag, sad), sadd), saddd) ->
      Noeud(Noir, p, Noeud(Rouge, x, sag, sad), Noeud(Rouge, g, sadd, saddd))
  (*cas 2 :*)
    |Noeud(Noir, g, Noeud(Rouge, p, sag, Noeud(Rouge, x, sagg, sadd)), Noeud(Noir, f, saggg, saddd)) ->
      Noeud(Noir, g, Noeud(Rouge, x, Noeud(Rouge, p, sag, sagg), sadd), Noeud(Noir, f, saggg, saddd))
    |Noeud(Noir, g, Noeud(Rouge, p, sag, Noeud(Rouge, x, sagg, sadd)), saddd) ->
      Noeud(Noir, g, Noeud(Rouge, x, Noeud(Rouge, p, sag, sadd), sadd), saddd)
  (*cas 3 :*)
    |Noeud(Noir, g, Noeud(Noir, f, sag, sad), Noeud(Rouge, p, Noeud(Rouge, x, sagg, sadd), saddd)) ->
      Noeud(Noir, g, Noeud(Noir, f, sag, sad), Noeud(Rouge, x, sagg, Noeud(Rouge, p, sadd, saddd)))
    |Noeud(Noir, g, sag, Noeud(Rouge, p, Noeud(Rouge, x, sagg, sadd), saddd)) ->
      Noeud(Noir, g, sag, Noeud(Rouge, x, sagg, Noeud(Rouge, p, sadd, saddd)))
  (*cas 4 :*)
    |Noeud(Noir, g, Noeud(Noir, f, sag, sad), Noeud(Rouge, p, sagg, Noeud(Rouge, x, saggg, saddd))) ->
      Noeud(Noir, p, Noeud(Rouge, g, Noeud(Noir, f, sag, sad), sagg), Noeud(Rouge, x, saggg, saddd))
    |Noeud(Noir, g, sag, Noeud(Rouge, p, sagg, Noeud(Rouge, x, saggg, saddd))) ->
      Noeud(Noir, p, Noeud(Rouge, g, sag, sagg), Noeud(Rouge, x, saggg, saddd))
  (*cas d'arret *)
    |_ -> arb;;

  let rec inser_rech e a = match a with
      Vide 
      -> Noeud(Rouge, e, Vide, Vide)
    | Noeud(c, i, sag, sad) when ((Ord.compare e i) = -1) 
	-> (equilibre (Noeud(c, i, (inser_rech e sag), sad)))
    | Noeud(c, i, sag, sad) when ((Ord.compare e i) = 1)
	-> (equilibre (Noeud(c, i, sag, (inser_rech e sad))))
    | _ -> a
  ;;

  let inser_bicolore e a = 
    let (Noeud(c, i, sag, sad)) = (inser_rech e a) 
    in
    Noeud(Noir, i, sag, sad)
  ;;

  let suppression_equilibreg =
    function 
  Noeud (Noir,i,Vide,Noeud (Noir,i2,Vide,Vide)) -> 
    (false,Noeud (Noir,i,Vide,Noeud (Rouge,i2,Vide,Vide)))
    | Noeud (Noir,i,
	     Vide,
	     Noeud (Noir,i2,(Noeud (Rouge,i3,Vide,Vide)),Vide)) ->
      (true,Noeud (Noir,i3,(Noeud (Noir,i,Vide,Vide)),
		   (Noeud (Noir,i2,Vide,Vide))))
    | Noeud (Noir,i,
	     Vide,
	     Noeud (Noir,i2,Vide,(Noeud (Rouge,i3,Vide,Vide)))) ->
      (true,Noeud (Noir,i2,(Noeud (Noir,i,Vide,Vide)),
		   (Noeud (Noir,i3,Vide,Vide))))
    | Noeud (Noir,i,Vide,Noeud (Noir,i2,(Noeud (Rouge,i3,Vide,Vide)),
				(Noeud (Rouge,i4,Vide,Vide)))) -> 
      (true,Noeud (Noir,i2,
		   (Noeud (Noir,i,Vide,(Noeud (Rouge,i3,Vide,Vide)))),
		   (Noeud (Noir,i4,Vide,Vide))))
    | Noeud (Noir,i,Vide,Noeud (Rouge,i2,(Noeud (Noir,i3,Vide,Vide)),
				(Noeud (Noir,i4,ag4,ad4)))) -> 
      (true,(Noeud (Noir,i2,
		    (Noeud (Noir,i,
			    Vide,
			    (Noeud (Rouge,i3,Vide,Vide)))),
		    (Noeud (Noir,i4,ag4,ad4)))))
    | Noeud (Noir,i,Vide,Noeud (Rouge,i2,
				(Noeud (Noir,i3,
					(Noeud (Rouge,i5,Vide,Vide)),Vide)),
				(Noeud (Noir,i4,ag4,ad4)))) -> 
      (true,(Noeud (Noir,i2,
		    (Noeud (Noir,i5,
			    (Noeud (Rouge,i,Vide,Vide)),
			    (Noeud (Rouge,i3,Vide,Vide)))),
		    (Noeud (Noir,i4,ag4,ad4)))))
    | Noeud (Noir,i,
	     Vide,
	     Noeud (Rouge,i2,
		    Noeud (Noir,i3,
			   ag3,
			   Noeud (Rouge,i5,Vide,Vide)),
		    Noeud (Noir,i4,ag4,ad4))) -> 
      (true,Noeud (Noir,i3,
		   Noeud (Noir,i,
			  Vide,
			  ag3),
		   Noeud (Rouge,i2,
			  Noeud (Noir,i5,Vide,Vide),
			  Noeud (Noir,i4,ag4,ad4))))
    | Noeud (Rouge,i,Vide,Noeud (Noir,i2,Vide,Vide)) ->
      (true,Noeud (Noir,i,Vide,Noeud (Rouge,i2,Vide,Vide)))
    | Noeud (Rouge,i,
	     Vide,
	     Noeud (Noir,i2,(Noeud (Rouge,i3,Vide,Vide)),Vide)) -> 
      (true,Noeud (Noir,i3,(Noeud (Rouge,i,Vide,Vide)),
		   (Noeud (Rouge,i2,Vide,Vide))))
    | Noeud (Rouge,i,
	     Vide,
	     Noeud (Noir,i2,Vide,(Noeud (Rouge,i3,Vide,Vide)))) ->
      (true,Noeud (Noir,i2,(Noeud (Rouge,i,Vide,Vide)),
		   (Noeud (Rouge,i3,Vide,Vide))))
    | Noeud (Rouge,i,Vide,Noeud (Noir,i2,(Noeud (Rouge,i3,Vide,Vide)),
				 (Noeud (Rouge,i4,Vide,Vide)))) -> 
      (true,Noeud (Rouge,i2,
		   (Noeud (Noir,i,Vide,(Noeud (Rouge,i3,Vide,Vide)))),
		   (Noeud (Noir,i4,Vide,Vide))))
    | Noeud (Noir,i,Noeud (Noir,i2,ag2,ad2),
	     Noeud (Noir,i3,
		    Noeud (Noir,i4,ag4,ad4),
		    Noeud (Noir,i5,ag5,ad5))) ->
      (false,Noeud (Noir,i,Noeud (Noir,i2,ag2,ad2),
		    Noeud (Rouge,i3,
			   Noeud (Noir,i4,ag4,ad4),
			   Noeud (Noir,i5,ag5,ad5))))
    | Noeud (Noir,i,Noeud (Noir,i2,ag2,ad2),
	     Noeud (Noir,i3,Noeud (Rouge,i4,ag4,ad4),
		    Noeud (Noir,i5,ag5,ad5))) ->
      (true,Noeud (Noir,i4,Noeud (Noir,i,Noeud (Noir,i2,ag2,ad2),ag4),
		   Noeud (Noir,i3,ad4,Noeud (Noir,i5,ag5,ad5))))
    | Noeud (Noir,i,Noeud (Noir,i2,ag2,ad2),
	     Noeud (Noir,i3,Noeud (Noir,i4,ag4,ad4),
		    Noeud (Rouge,i5,ag5,ad5))) -> 
      (true,Noeud (Noir,i3,
		   Noeud (Noir,i,
			  Noeud (Noir,i2,ag2,ad2),
			  Noeud (Noir,i4,ag4,ad4)),
		   Noeud (Noir,i5,ag5,ad5)))
    | Noeud (Noir,i,Noeud (Noir,i2,ag2,ad2),
	     Noeud (Noir,i3,Noeud (Rouge,i4,ag4,ad4),
		    Noeud (Rouge,i5,ag5,ad5))) -> 
      (true,Noeud (Noir,i4,Noeud (Noir,i,Noeud (Noir,i2,ag2,ad2),ag4),
		   Noeud (Noir,i3,ad4,Noeud (Rouge,i5,ag5,ad5))))
    | Noeud (Noir,i,Noeud (Noir,i2,ag2,ad2),
	     Noeud (Rouge,i3,
		    Noeud (Noir,i4,
			   Noeud (Noir,i6,ag6,ad6),
			   Noeud (Noir,i7,ag7,ad7)),
		    Noeud (Noir,i5,ag5,ad5))) -> 
      (true,Noeud (Noir,i3,
		   Noeud (Noir,i,
			  Noeud (Noir,i2,ag2,ad2),
			  Noeud (Rouge,i4,
				 Noeud (Noir,i6,ag6,ad6),
				 Noeud (Noir,i7,ag7,ad7))),
		   Noeud (Noir,i5,ag5,ad5)))
    | Noeud (Noir,i,Noeud (Noir,i2,ag2,ad2),
	     Noeud (Rouge,i3,
		    Noeud (Noir,i4,
			   Noeud (Rouge,i6,ag6,ad6),
			   Noeud (Noir,i7,ag7,ad7)),
		    Noeud (Noir,i5,ag5,ad5))) -> 
      (true,Noeud (Noir,i3,
		   Noeud (Rouge,i6,
			  Noeud (Noir,i,Noeud (Noir,i2,ag2,ad2),ag6),
			  Noeud (Noir,i4,ad6,
				 Noeud (Noir,i7,ag7,ad7))),
		   Noeud (Noir,i5,ag5,ad5)))
    | Noeud (Noir,i,Noeud (Noir,i2,ag2,ad2),
	     Noeud (Rouge,i3,
		    Noeud (Noir,i4,
			   Noeud (Noir,i6,ag6,ad6),
			   Noeud (Rouge,i7,ag7,ad7)),
		    Noeud (Noir,i5,ag5,ad5))) -> 
      (true,Noeud (Noir,i3,
		   Noeud (Rouge,i4,
			  Noeud (Noir,i,
				 Noeud (Noir,i2,ag2,ad2),
				 Noeud (Noir,i6,ag6,ad6)),
			  Noeud (Noir,i7,ag7,ad7)),
		   Noeud (Noir,i5,ag5,ad5)))
    | Noeud (Noir,i,Noeud (Noir,i2,ag2,ad2),
	     Noeud (Rouge,i3,
		    Noeud (Noir,i4,
			   Noeud (Rouge,i6,ag6,ad6),
			   Noeud (Rouge,i7,ag7,ad7)),
		    Noeud (Noir,i5,ag5,ad5))) -> 
      (true,Noeud (Noir,i3,
		   Noeud (Rouge,i4,
			  Noeud (Noir,i,
				 Noeud (Noir,i2,ag2,ad2),
				 Noeud (Rouge,i6,ag6,ad6)),
			  Noeud (Noir,i7,ag7,ad7)),
		   Noeud (Noir,i5,ag5,ad5)))
    | Noeud (Noir,i,Noeud (Rouge,i2,ag2,ad2),ad) -> 
      (true,Noeud (Noir,i,Noeud (Noir,i2,ag2,ad2),ad)) 
    | Noeud (Rouge,i,
	     Noeud (Noir,i2,ag2,ad2),
	     Noeud (Noir,i3,Noeud (Noir,i4,ag4,ad4),ad3)) ->
      (true,Noeud (Noir,i3,
		   Noeud (Rouge,i,
			  Noeud (Noir,i2,ag2,ad2),
			  Noeud (Noir,i4,ag4,ad4)),
		   ad3))
    | Noeud (Rouge,i,
	     Noeud (Noir,i2,ag2,ad2),
	     Noeud (Noir,i3,Noeud (Rouge,i4,ag4,ad4),ad3)) ->
      (true,Noeud (Rouge,i4,
		   Noeud (Noir,i,
			  Noeud (Noir,i2,ag2,ad2),
			  ag4),
		   Noeud (Noir,i3,ad4,ad3)))
    | a -> (true,a)
  ;;

  let suppression_equilibred = function 
  Noeud (Noir,i,Noeud (Noir,i2,Vide,Vide),Vide) -> 
    (false,Noeud (Noir,i,Noeud (Rouge,i2,Vide,Vide),Vide))
    | Noeud (Noir,i,
	     Noeud (Noir,i2,(Noeud (Rouge,i3,Vide,Vide)),Vide),
	     Vide) ->  
      (true,Noeud (Noir,i2,(Noeud (Noir,i3,Vide,Vide)),
		   (Noeud (Noir,i,Vide,Vide))))
    | Noeud (Noir,i,
	     Noeud (Noir,i2,Vide,(Noeud (Rouge,i3,Vide,Vide))),
	     Vide) ->
      (true,Noeud (Noir,i3,(Noeud (Noir,i2,Vide,Vide)),
		   (Noeud (Noir,i,Vide,Vide))))
    | Noeud (Noir,i,Noeud (Noir,i2,(Noeud (Rouge,i3,Vide,Vide)),
			   (Noeud (Rouge,i4,Vide,Vide))),Vide) -> 
      (true,Noeud (Noir,i2,
		   (Noeud (Noir,i3,Vide,Vide)),
		   (Noeud (Noir,i,(Noeud (Rouge,i4,Vide,Vide)),Vide))))
    | Noeud (Noir,i,
	     Noeud (Rouge,i2,
		    Noeud (Noir,i3,ag3,ad3),
		    Noeud (Noir,i4,
			   Noeud (Rouge,i5,Vide,Vide),
			   ad4)),
	     Vide) -> 
      (true,Noeud (Noir,i2,
		   Noeud (Noir,i3,ag3,ad3),
		   Noeud (Rouge,i4,
			  Noeud (Noir,i5,Vide,Vide),
			  Noeud (Noir,i,ad4,Vide))))
    | Noeud (Noir,i,
	     Noeud (Rouge,i2,
		    Noeud (Noir,i3,ag3,ad3),
		    Noeud (Noir,i4,Vide,Vide)),
	     Vide) ->
      (true,Noeud (Noir,i2,
		   Noeud (Noir,i3,ag3,ad3),
		   Noeud (Noir,i,
			  Noeud (Rouge,i4,Vide,Vide),
			  Vide)))
    | Noeud (Noir,i,
	     Noeud (Rouge,i2,
		    Noeud (Noir,i3,ag3,ad3),
		    Noeud (Noir,i4,
			   Vide,
			   Noeud (Rouge,i5,Vide,Vide))),
	     Vide) ->
      (true,Noeud (Noir,i2,
		   Noeud (Noir,i3,ag3,ad3),
		   Noeud (Noir,i5,
			  Noeud (Rouge,i4,Vide,Vide),
			  Noeud (Rouge,i,Vide,Vide))))
    | Noeud (Rouge,i,Noeud (Noir,i2,Vide,Vide),Vide) ->	
      (true,Noeud (Noir,i,Noeud (Rouge,i2,Vide,Vide),Vide))
    | Noeud (Rouge,i,
	     Noeud (Noir,i2,(Noeud (Rouge,i3,Vide,Vide)),Vide),
	     Vide) -> 
      (true,Noeud (Noir,i2,(Noeud (Rouge,i3,Vide,Vide)),
		   (Noeud (Rouge,i,Vide,Vide))))
    | Noeud (Rouge,i,
	     Noeud (Noir,i2,Vide,(Noeud (Rouge,i3,Vide,Vide))),
	     Vide) ->
      (true,Noeud (Noir,i3,
		   (Noeud (Rouge,i2,Vide,Vide)),
		   (Noeud (Rouge,i,Vide,Vide))))
    | Noeud (Rouge,i,Noeud (Noir,i2,(Noeud (Rouge,i3,Vide,Vide)),
			    (Noeud (Rouge,i4,Vide,Vide))),Vide) -> 
      (true,Noeud (Rouge,i2,
		   (Noeud (Noir,i3,Vide,Vide)),
		   (Noeud (Noir,i,(Noeud (Rouge,i4,Vide,Vide)),Vide))))
    | Noeud (Noir,i,
	     Noeud (Noir,i3,
		    Noeud (Noir,i4,ag4,ad4),
		    Noeud (Noir,i5,ag5,ad5)),
	     Noeud (Noir,i2,ag2,ad2)) -> 
      (false,Noeud (Noir,i3,
		    Noeud (Noir,i4,ag4,ad4),
		    Noeud (Rouge,i,
			   Noeud (Noir,i5,ag5,ad5),
			   Noeud (Noir,i2,ag2,ad2))))
    | Noeud (Noir,i,
	     Noeud (Noir,i3,
		    Noeud (Rouge,i4,ag4,ad4),
		    Noeud (Noir,i5,ag5,ad5)),
	     Noeud (Noir,i2,ag2,ad2)) ->
      (true,Noeud (Noir,i3,
		   Noeud (Noir,i4,ag4,ad4),
		   Noeud (Noir,i,
			  Noeud (Noir,i5,ag5,ad5),
			  Noeud (Noir,i2,ag2,ad2))))
    | Noeud (Noir,i,
	     Noeud (Noir,i3,
		    Noeud (Noir,i4,ag4,ad4),
		    Noeud (Rouge,i5,ag5,ad5)),
	     Noeud (Noir,i2,ag2,ad2)) -> 
      (true,Noeud (Noir,i5,
		   Noeud (Noir,i3,
			  Noeud (Noir,i4,ag4,ad4),
			  ag5),
		   Noeud (Noir,i,
			  ad5,
			  Noeud (Noir,i2,ag2,ad2)))) 
    | Noeud (Noir,i,
	     Noeud (Noir,i3,
		    Noeud (Rouge,i4,ag4,ad4),
		    Noeud (Rouge,i5,ag5,ad5)),
	     Noeud (Noir,i2,ag2,ad2)) -> 
      (true,Noeud (Noir,i5,
		   Noeud (Noir,i3,
			  Noeud (Rouge,i4,ag4,ad4),ag5),
		   Noeud (Noir,i,ad5,Noeud (Noir,i2,ag2,ad2))))	
    | Noeud (Noir,i,
	     Noeud (Rouge,i3,
		    Noeud (Noir,i4,
			   Noeud (Noir,i6,ag6,ad6),
			   Noeud (Noir,i7,ag7,ad7)),
		    Noeud (Noir,i5,ag5,ad5)),
	     Noeud (Noir,i2,ag2,ad2)) -> 
      (true,Noeud (Noir,i5,
		   Noeud (Noir,i3,
			  Noeud (Rouge,i4,
				 Noeud (Noir,i6,ag6,ad6),
				 Noeud (Noir,i7,ag7,ad7)),
			  ag5),
		   Noeud (Noir,i,ad5,Noeud (Noir,i2,ag2,ad2))))
    | Noeud (Noir,i,
	     Noeud (Rouge,i3,
		    Noeud (Noir,i4,
			   Noeud (Rouge,i6,ag6,ad6),
			   Noeud (Noir,i7,ag7,ad7)),
		    Noeud (Noir,i5,ag5,ad5)),
	     Noeud (Noir,i2,ag2,ad2)) -> 
      (true,Noeud (Noir,i5,
		   Noeud (Rouge,i4,
			  Noeud (Noir,i6,ag6,ad6),
			  Noeud (Noir,i3,
				 Noeud (Noir,i7,ag7,ad7),
				 ag5)),
		   Noeud (Noir,i,ad5,Noeud (Noir,i2,ag2,ad2))))
    | Noeud (Noir,i,
	     Noeud (Rouge,i3,
		    Noeud (Noir,i4,
			   Noeud (Noir,i6,ag6,ad6),
			   Noeud (Rouge,i7,ag7,ad7)),
		    Noeud (Noir,i5,ag5,ad5)),
	     Noeud (Noir,i2,ag2,ad2)) -> 
      (true,Noeud (Noir,i5,
		   Noeud (Rouge,i7,
			  Noeud (Noir,i4,
				 Noeud (Noir,i6,ag6,ad6),
				 ag7),
			  Noeud (Noir,i3,ad7,ag5)),
		   Noeud (Noir,i,ad5,Noeud (Noir,i2,ag2,ad2)))) 
    | Noeud (Noir,i,
	     Noeud (Rouge,i3,
		    Noeud (Noir,i4,
			   Noeud (Rouge,i6,ag6,ad6),
			   Noeud (Rouge,i7,ag7,ad7)),
		    Noeud (Noir,i5,ag5,ad5)),
	     Noeud (Noir,i2,ag2,ad2)) -> 
      (true,Noeud (Noir,i5,
		   Noeud (Rouge,i4,
			  Noeud (Noir,i6,ag6,ad6),
			  Noeud (Noir,i3,
				 Noeud (Rouge,i7,ag7,ad7),
				 ag5)),
		   Noeud (Noir,i,
			  ad5, 
			  Noeud (Noir,i2,ag2,ad2))))
    | Noeud (Noir,i,ag,Noeud (Rouge,i2,ag2,ad2)) ->
      (true,Noeud (Noir,i,ag,Noeud (Noir,i2,ag2,ad2)))
    | Noeud (Rouge,i,
	     Noeud (Noir,i2,ag2,
		    Noeud (Noir,i4,ag4,ad4)),
	     Noeud (Noir,i3,ag3,ad3)) -> 
      (true,Noeud (Noir,i2,ag2,
		   Noeud (Rouge,i,
			  Noeud (Noir,i4,ag4,ad4),
			  Noeud (Noir,i3,ag3,ad3))))
    | Noeud (Rouge,i,
	     Noeud (Noir,i2,ag2,
		    Noeud (Rouge,i4,ag4,ad4)),
	     Noeud (Noir,i3,ag3,ad3)) -> 
      (true,Noeud (Rouge,i4,
		   Noeud (Noir,i2,ag2,ag4),
		   Noeud (Noir,i,ad4,
			  Noeud (Noir,i3,ag3,ad3))))
    | a -> (true,a)
  ;;

  let rec succ_arbre = function
  Noeud(Rouge, i, Vide, Vide) -> (true, i, Vide)

    |Noeud(Noir, i, Vide, Vide) -> (false, i, Vide)

    |Noeud(Noir, i, Vide, Noeud(Rouge, ii, Vide, Vide)) ->
      (true, i, Noeud(Noir, ii, Vide, Vide))

    |Noeud(c, i, sag, sad) ->
      (let (b, x, a) = (succ_arbre sag) in
       (if b then
           (true, x, Noeud(c, i, a, sad))
	else
	   (let (b2,a2) = (suppression_equilibreg(Noeud(c, i, a, sad)))
	    in
	    (b2, x, a2))))
    |_ -> failwith "erreur"
  ;;

  let rec suppression_rech (e : element) a = match a with
      Vide -> (true,Vide)
    | Noeud (c, i, ag, ad) when ((Ord.compare i e) = 1) ->
      (
	let (b, a2) = (suppression_rech e ag) in
	(
	  if b then 
	    (true, Noeud (c, i, a2, ad))
	  else 
	    (suppression_equilibreg (Noeud (c,i,a2,ad)))
	)
      )
    | Noeud (c,i,ag,ad) when ((Ord.compare i e) = -1) ->
      (
	let (b, a2) = (suppression_rech e ad) in
	(
	  if b then 
	    (true, Noeud (c, i, ag, a2))
	  else 
	    (suppression_equilibred (Noeud (c,i,ag,a2)))
	)
      )
    | Noeud (c, i, ag, ad) -> (match ad with
      Vide -> (match ag with
	Vide when (c = Rouge) -> (true, Vide)
      | Vide                  -> (false, Vide)
      | Noeud (Rouge, i2, Vide, Vide) -> (true,Noeud (Noir,i2,Vide,Vide))
      | _ -> failwith "erreur")
      | Noeud (c2,i2,ag2,ad2) ->
	(
	  let (b, x, a2) = (succ_arbre (Noeud (c2, i2, ag2, ad2))) 
	  in
	  (
	    if b	then (true, Noeud (c, x, ag, a2))
	    else 
	      (suppression_equilibred (Noeud (c,x,ag,a2)))
	  )
	))
  ;;

  let suppression (e : element) a =
    (snd (suppression_rech e a))
  ;;

  let est_vide a = match a with 
      Vide -> true
    |_ -> false
  ;;

  let appartient_a e (a : element) =
    recherche_abc e a
  ;;

  let inserer e a =
    inser_bicolore e a
  ;;

  let supprimer (e : element) a =
    suppression e a
  ;;

  let rec min a = match a with
      Vide -> failwith"pas de valeur dans abr"
    |Noeud(c,v,Vide,_) -> v
    |Noeud(c,v,sag,sad) -> min(sag)
  ;;

  let rec max a = match a with
      Vide -> failwith"pas de valeur dans abr"
    |Noeud(c,v,_,Vide) -> v
    |Noeud(c,v,sag,sad) -> max(sad)
  ;;

  let decouper_selon_min a = 
    ((min a), (supprimer (min a) a))
  ;;

  let decouper_selon_max a = 
    ((max a), (supprimer (max a) a))
  ;;

  let union e1 e2 =
    let rec aux efin e1 e2 = 
      if ((est_vide e1) = true  && (est_vide e2) = true) then
	efin
      else if ((est_vide e1) = true && (est_vide e2) = false) then
	(aux (inserer (max e2) efin) e1 (supprimer (max e2) e2))
      else if ((est_vide e1) = false  && (est_vide e2) = true) then 
	(aux (inserer (max e1) efin) (supprimer (max e1) e1) e2)
      else 
	(aux (inserer (max e2) (inserer (max e1) efin)) (supprimer (max e1) e1) (supprimer (max e2) e2))
    in 
    (aux Vide e1 e2)
  ;;

  let intersection e1 e2 =
    let rec aux efin e1 e2 =
      if ((est_vide e1) = true || (est_vide e2) = true) then
	efin
      else 
	if (appartient_a e2 (max e1)) then 
	  (aux (inserer (max e1) efin) (supprimer (max e1) e1) e2)
	else 
	  (aux efin (supprimer (max e1) e1) e2)
    in
    (aux Vide e1 e2)
  ;;
  
  let liste_vers_ensemble l = 
    let rec aux l a = match l with 
	[] -> a
      | e::l1 -> (aux l1 (inserer e a))
    in 
    (aux l Vide);;

  let ensemble_vers_liste e =
    let rec ensemble_vers_liste_rec ens =
      match ens with
	e when ((est_vide e) = true) -> []
      |_ -> let (min, ensmin) = decouper_selon_min ens in
	    [min] @ (ensemble_vers_liste_rec ensmin)
    in
    ensemble_vers_liste_rec e
  ;;
 
  let rec inclus e1 e2 = 
    match e1 with
	e1 when ((est_vide e1) = true) -> true
      | ens -> let (i, ensmin) = decouper_selon_min ens in 
	if (appartient_a e2 i) then 
	  inclus ensmin e2
	else
	  false
  ;;

  let egal e1 e2 = 
    (inclus e1 e2) && (inclus e2 e1)
  ;;

  type ensCo = abc;;
  
  let ensembleComplet = 
    Vide
  ;;

  let unionC (a : ensCo) (b : ensCo) = 
    ((intersection a b) : ensCo)
  ;;

  let intersectionC (a : ensCo) (b : ensCo) = 
    ((union a b) : ensCo)
  ;;

  let insertionC (e : element) (ens : ensCo) = 
    ((supprimer e ens) : ensCo)
  ;;
  
  let suppressionC e (ens : ensCo) = 
    ((inserer e ens) : ensCo)
  ;;

  let estDansC (e : element) (ens : ensCo) =
    if (appartient_a ens e) then
      false
    else 
      true
  ;; 

  let estinclusC (e1 : ensCo) (e2 : ensCo) =
    (inclus e2 e1)
  ;;

  let estegalC (e1 : ensCo) (e2 : ensCo) = 
    ((estinclusC e1 e2) && (estinclusC e2 e1))
  ;;

  type ensFin = abc;;

  let ensVide = 
    (Vide : ensFin)
  ;;

  let negF (ens : ensFin) = 
    (ens : ensCo)
  ;; 

  let negC (ens : ensCo) = 
    (ens : ensFin)
  ;;

  let unionF (a : ensFin) (b : ensFin) =
    ((union a b) : ensFin)
  ;;
  
  let intersectionF (a : ensFin) (b : ensFin) = 
    ((intersection a b) : ensFin)
  ;;

  let insertionF e (ens : ensFin) = 
    ((inserer e ens) : ensFin)
  ;;
  
  let suppressionF (e : element) (ens : ensFin) = 
    ((supprimer e ens) : ensFin)
  ;;

  let estDansF (e : element) (ens : ensFin) = 
    (appartient_a ens e)
  ;;

  let estinclusF (e1 : ensFin) (e2 : ensFin) =
    (inclus e1 e2)
  ;;

  let estegalF (e1 : ensFin) (e2 : ensFin) = 
    (egal e1 e2)
  ;; 

  let minF (e : ensFin) =
    (min e)
  ;;

  let maxF (e : ensFin) =
    (max e)
  ;;
  
    (* true = ensCo et false = ensFin *)

  type flag = bool;;
  type ensemble = abc;;
  type ens = flag * ensemble;;

  let negE (a : ens) = match a with
      (true, e) -> ((false, (negC  (e : ensCo))) : ens)
    |(false, e) -> ((true, (negF (e : ensFin))) : ens)
  ;;

  let unionE (a : ens) (b : ens) =
    let rec aux a b =  match (a, b) with 
	((true, e), (true, f)) -> ((true, (unionC e f)) : ens)
      | ((false, e), (true, f)) -> 
	( match (e, f) with 
	  (Vide, res) -> ((true, res) : ens)
	| (ef, fc) ->  
          let min = (decouper_selon_min ef) 
          in
	  if (estDansC (fst min) fc) then
	    (aux (false, (snd min)) (true, fc))
	  else 
	    (aux (false, (snd min)) (true, (insertionC (fst min) fc)))  
	  
	)
      | ((true, e),(false, f)) -> 
	( match (e, f) with 
	  (res, Vide) -> ((true, res) : ens)
	| (ec, ff) ->  
          let min = (decouper_selon_min ff) 
          in
	  if (estDansC (fst min) ec) then
	    (aux (true, ec) (false, (snd min)))
	  else 
	    (aux (true, insertionC (fst min) ec) (false, (snd min)))
	)
      | ((false, e),(false, f)) -> ((false, unionF e f) : ens)
    in (aux a b)
  ;;

  let intersectionE (a : ens) (b : ens) =
    let rec aux a b = match (a,b) with 
	((true, e), (true, f)) -> ((true, (intersectionC e f)) : ens)
      | ((false, e), (true, f)) -> 
	( match (e, f) with 
	  (res, Vide) -> ((false, res) : ens)
	| (ef, fc) ->  
          let min = (decouper_selon_min fc) 
          in
	  if (estDansF (fst min) ef) then
	    (aux (false, (suppressionF (fst min) ef)) (true, (snd min)))
	  else
	    (aux (false, ef) (true, (snd min)))  
	)
      | ((true, e), (false, f)) ->
	(
	  match (e, f) with 
	    (Vide, res) -> ((false, res) : ens)
	  | (ec, ff) ->  
            let min = (decouper_selon_min ec) 
            in
	    if (estDansF (fst min) ff) then
	      (aux (false, (suppressionF (fst min) ff)) (true, (snd min)))
	    else
	      (aux (false, ff) (true, (snd min)))
	)
      | ((false, e), (false, f)) -> ((false, (intersectionC e f)) : ens)
    in (aux a b)
  ;;
  
  let differenceE (a : ens) (b : ens) = match (a, b) with 
      ((true, e), (true, f)) -> ((false, (intersectionF e (negC f))) : ens)
    | ((false, e), (true, f)) -> ((false, (intersectionF e (negC f))) : ens)
    | ((true, e), (false, f)) -> ((true, (intersectionC e (negF f))) : ens)
    | ((false, e), (false, f)) -> ((false, (intersectionF e (negF f))) : ens)
  ;;

  let difference_symE (a : ens) (b : ens) = 
    (unionE (differenceE a b) (differenceE b a))
  ;;

  let insertionE e (a : ens) = match a with 
      (true, en)  -> ((true, (insertionC e (en : ensCo))) : ens)
    | (false, en) -> ((false, (insertionF e (en : ensFin))) : ens)
  ;;

  let suppressionE e (a : ens) = match a with 
      (true, en)  -> ((true, (suppressionC e (en : ensCo))) : ens)
    | (false, en) -> ((false, (suppressionF e (en : ensFin))) : ens)
  ;;

  let estDansE (e : element) (a : ens) = match a with 
      (true, en) -> (estDansC e (en : ensCo))
    | (false, en) -> (estDansF e (en : ensFin))
  ;;

(* true si e1 est dans e2, false sinon *)
  let estinclusE (e1 : ens) (e2 : ens) = 
    let rec aux e1 e2 = match (e1 ,e2) with 
      ((true, en1), (true, en2)) -> (estinclusC en1 en2)
    | ((false, en1), (true, en2)) -> 
      (
	match (en1, en2) with 
	    (Vide, res) -> true
	  | (ef, fc) ->  
            let min = (decouper_selon_min ef) 
            in
	    if (estDansC (fst min) fc) then
	      (aux (false, (snd min)) (true, fc))
	    else
	      false
      )
    | ((true, en1), (false, en2)) -> failwith "un ensemble cofini ne peut �tre dans un ensemble fini"
    | ((false, en1), (false, en2)) -> (estinclusF en1 en2)
    in 
    (aux e1 e2)
  ;;
    

  let estegalE (e1 : ens) (e2 : ens) = 
    (estinclusE e1 e2) && (estinclusE e2 e1)
  ;; 

  let minE (e : ens) = match e with
      (true, en) -> failwith "un ensemble cofini n'a pas de minimum"
    | (false, en) -> (minF en)
  ;; 

  let maxE (e : ens) = match e with
      (true, en) -> failwith "un ensemble cofini n'a pas de maximum"
    | (false, en) -> (maxF en)
  ;;  
 
end



