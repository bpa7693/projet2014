#use "projet2014.ml";;

module MakeCoupleInt = EnsembleEntiers(CoupleInt);;
open MakeCoupleInt;;

let ens = liste_vers_ensemble ([(1, 1);(1, 2);(1, 3);(1 ,4);(1, 5);(1, 6);(1, 8)]);;
let ens1 = liste_vers_ensemble ([(1, 8);(1, 9);(1, 10);(1, 11);(1, 12);(1, 13);(1, 14)]);;
let ens14b = liste_vers_ensemble([(1, 5);(1, 6)]);;

(* Exemples pour les ensembles cofinis. *)

let ens2 = ensembleComplet;;
let ens3 = unionC ens ens1;;
let ens4 = intersectionC ens ens1;;
let ens5 = insertionC (1, 1) ens;;
let ens6 = suppressionC (1, 1) ens1;;
let bool7 = estDansC (1, 1) ens;;
let bool8 = (estinclusC ens ens14b);;
let bool9 = (estegalC ens14b ens14b);;

(* Exemples pour les ensembles finis. *)

let ens8 = ensVide;;
let ens9 = negF ens;;
let ens10 = negC ens9;;
let ens11 = unionF ens ens1;;
let ens12 = insertionF (1, 1) ens1;;
let ens13 = suppressionF (1, 1) ens;;
let bool14 = estDansF (1, 4) ens;;
let bool15 = (estinclusF ens14b ens);;
let bool16 = (estegalF ens14b ens14b);;
let elt17 = (minF ens14b);;
let elt18 = (maxF ens14b);;

(* Exemples pour les ensembles. *)

let ens15 = (false, liste_vers_ensemble ([(1, 5);(1, 6);(1, 7);(1, 8)]));;
let ens16 = (true, liste_vers_ensemble ([(1, 7);(1, 8);(1, 9);(1, 10)]));;
let ens17 = negE ens15;;
let ens18 = unionE ens15 ens16;;
let ens19 = unionE ens16 ens15;;
let ens20 = intersectionE ens15 ens16;;
let ens21 = intersectionE ens16 ens15;;
let ens22 = differenceE ens15 ens16;;
let ens23 = differenceE ens16 ens15;;
let ens24 = difference_symE ens15 ens16;;
let ens25 = insertionE (1, 11) ens15;;
let ens26 = insertionE (1, 8) ens16;;
let ens27 = suppressionE (1, 8) ens15;;
let ens28 = suppressionE (1, 11) ens16;;
let bool29 = estDansE (1, 8) ens15;;
let bool30 = estDansE (1, 11) ens16;;
let ens31 = (false, liste_vers_ensemble ([(1, 5);(1, 6)]));;
let bool32 = (estinclusE ens31 ens15);;
let bool33 = (estinclusE ens31 ens16);;
let bool34 = (estegalE ens15 ens15);;
let elt35 = minE ens31;;
let elt36 = maxE ens31;;


